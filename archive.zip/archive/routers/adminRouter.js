// import express from 'express';
// import eraporController from '../controller/e-raporController.js';

// const router = express.Router();

// // Admin
// router.get('/admin', eraporController.getViewAuthAdminLogin);
// router.get('/admin/dashboard', eraporController.getViewAdminDashboard);
// router.get('/admin/logout', eraporController.getViewAdminLogout);

// export default router;
