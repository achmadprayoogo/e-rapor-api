// import express from 'express';
// import eraporController from '../controller/e-raporController.js';

// const router = express.Router();

// // User
// router.get('/', eraporController.getViewAuthUser);
// router.get('/erapor', eraporController.getViewEraporUser);

// export default router;
